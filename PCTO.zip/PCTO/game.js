let razzoImg;
let backgroundImg;
let moon;
let immagineTerra;
let immagineLuna;
let immagineMarte;
let punteggioAttuale = 0;
let punteggioPrecedente = 0;
let xRazzo, yRazzo;
let currentPlanet = "earth";

function preload() {
    razzoImg = loadImage("./img/razzo.png");
    immagineTerra = loadImage("./img/earthView.jpg");
    immagineLuna = loadImage("./img/moonView.jpg");
    immagineMarte = loadImage("./img/marsView.jpg");
}

function setup() {
    createCanvas(1520, 700);
    frameRate(60);
    razzoImg.resize(180, 0);

    // Imposta le coordinate iniziali del razzo sopra l'immagine della Terra
    xRazzo = width / 2 - razzoImg.width / 2;
    yRazzo = height - height / 8 - razzoImg.height;
}

function draw() {
    // Pulisci il canvas
    background(0); // Cambia il colore di sfondo in base alle tue esigenze

    // Disegna l'immagine del pianeta corrente
    switch (currentPlanet) {
        case "earth": 
            image(immagineTerra, 0, 0, width, height);
            break;
        case "moon":
            image(immagineLuna, 0, 0, width, height);
            break;
        case "mars":
            image(immagineMarte, 0, 0, width, height);
            break;
    }
    
    // Disegna l'immagine del razzo
    image(razzoImg, xRazzo, yRazzo);
}

function keyPressed() {
    if (keyCode === ENTER) {
        punteggioPrecedente = punteggioAttuale;
        punteggioAttuale++;
     
        if (punteggioAttuale > punteggioPrecedente) {
            yRazzo -= 50;

            // Se il razzo è salito oltre la parte alta dello schermo
            if (yRazzo < 0) {
                // Cambia il pianeta in base alla situazione corrente
                if (currentPlanet === "earth") {
                    currentPlanet = "moon";
                } else if (currentPlanet === "moon") {
                    currentPlanet = "mars";
                }
                // Riposiziona il razzo nella parte inferiore dello schermo
                yRazzo = height - height / 8 - razzoImg.height;
            }
        }
    }
}
